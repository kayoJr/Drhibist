<ul class="list-unstyled components">
    <li>
        <a href="index.php"><i class="fa-solid fa-address-card"></i>
            <span>Patient</span></a>
    </li>
    <li>
        <a href="../../backend/logout.php"><i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout</span></a>
    </li>
</ul>