<ul class="list-unstyled components">
    <li class="active">
        <a href="index.php"><i class="fa-solid fa-address-card"></i>
            <span>Register</span></a>
    </li>
    <li>
        <a href="search.php"><i class="fa-solid fa-magnifying-glass"></i>
            <span>Search</span></a>
    </li>
    <li>
        <a href="../../backend/logout.php"><i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout</span></a>
    </li>
</ul>