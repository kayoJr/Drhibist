<?php

if(isset($_GET['test'])){
    $month = $_GET['month'];
    $year = $_GET['year'];
    
    echo $month;
    echo $year;
}

?>