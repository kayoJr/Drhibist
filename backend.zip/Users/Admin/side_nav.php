<ul class="list-unstyled components">
    <li class="active">
        <a href="index.php"><i class="fa-solid fa-home"></i>
            <span>Home</span></a>
    </li>
    <li>
        <a href="user.php"><i class="fa-solid fa-user"></i>
            <span>Users</span></a>
    </li>
    <li>
        <a href="addUser.php"><i class="fa-solid fa-user-plus"></i>
            <span>Add Users</span></a>
    </li>
    <li>
        <a href="pharmacy.php"><i class="fa-solid fa-prescription-bottle-medical"></i>
            <span>Pharmacy</span></a>
    </li>
    <li>
        <a href="../../backend/logout.php"><i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout</span></a>
    </li>
</ul>