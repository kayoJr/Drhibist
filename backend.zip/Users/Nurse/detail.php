<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- basic -->
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<!-- mobile metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="viewport" content="initial-scale=1, maximum-scale=1" />
		<!-- site metas -->
		<title>Reception</title>
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<meta name="author" content="" />
		<link
			href="https://fonts.googleapis.com/css2?family=Dosis:wght@200;300;400;600;700;800&display=swap"
			rel="stylesheet"
		/>
		<link
			rel="stylesheet"
			href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
			integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
			crossorigin="anonymous"
			referrerpolicy="no-referrer"
		/>
		<link rel="icon" href="../../img/favicon.ico" type="image/png" />
		<link rel="stylesheet" href="../styles/bootstrap.min.css" />
		<link rel="stylesheet" href="../styles/style.css" />
		<link rel="stylesheet" href="../styles/responsive.css" />
		<link rel="stylesheet" href="../styles/bootstrap-select.css" />
		<link rel="stylesheet" href="../styles/perfect-scrollbar.css" />
		<link rel="stylesheet" href="../styles/custom.css" />
	</head>
	<body class="dashboard dashboard_1">
		<div class="full_container">
			<div class="inner_container">
				<!-- Sidebar  -->
				<nav id="sidebar">
					<div class="sidebar_blog_1">
						<div class="sidebar-header">
							<div class="logo_section">
								<a href="index.html"
									><img
										class="logo_icon img-responsive"
										src="../../img/logo.png"
										alt="#"
								/></a>
							</div>
						</div>
						<div class="sidebar_user_info">
							<div class="icon_setting"></div>
							<div class="user_profle_side">
								<div class="user_img">
									<img
										class="img-responsive"
										src="../../img/logo.png"
										alt="#"
									/>
								</div>
								<div class="user_info">
									<h6>User Name</h6>
								</div>
							</div>
						</div>
					</div>
					<div class="sidebar_blog_2">
						<ul class="list-unstyled components">
							<li class="active">
								<a href="index.html"
									><i class="fa-solid fa-address-card"></i>
									<span>Record</span></a
								>
							</li>
						</ul>
					</div>
				</nav>
				<!-- end sidebar -->

				<!-- right content -->
				<div id="content">
					<!-- topbar -->
					<div class="topbar">
						<nav class="navbar navbar-expand-lg navbar-light">
							<div class="full">
								<button
									type="button"
									id="sidebarCollapse"
									class="sidebar_toggle"
								>
									<i class="fa-solid fa-bars"></i>
								</button>
								<div class="right_topbar"></div>
							</div>
						</nav>
					</div>
					<!-- end topbar -->

					<!-- dashboard inner -->
					<div class="midde_cont">
						<div class="container-fluid">
                            <form action="../../backend/nurse_exam.php" method="POST" class="search">
                                <h3>Add Result</h3>
                                <div class="form-elements">
                                    <div>
                                        <label for="bp">BP</label>
                                        <input type="number" name="bp" id="bp" required min="0">
                                    </div>
                                    <div>
                                        <label for="pr">PR</label>
                                        <input type="number" name="pr" id="pr" required min="0">
                                    </div>
                                    <div>
                                        <label for="saturation">Saturation</label>
                                        <input type="number" name="saturation" id="saturation" min="0" required>
                                    </div>
                                    <div>
                                        <label for="respiratory">Respiratory</label>
                                        <input type="number" name="respiratory" id="respiratory" min="0" required>
                                    </div>
                                    <div>
                                        <label for="temp">Temperature</label>
                                        <input type="number" name="temp" id="temp" min="0" required>
                                    </div>
                                    <div>
                                        <label for="height">Height</label>
                                        <input type="number" name="height" id="height" min="0" required>
                                    </div>
                                    <div>
                                        <label for="weight">Weight</label>
                                        <input type="number" name="weight" id="weight" min="0" required>
                                    </div>
                                    <div>
                                        <label for="head">Head Circumference</label>
                                        <input type="number" name="head" id="head" min="0" required>
                                    </div>
                                    <div>
                                        <label for="muac">MUAC</label>
                                        <input type="number" name="muac" id="muac" min="0" required>
                                    </div>
                                    <div>
										<?php
										$id = $_GET['id'];
										?>
										<input type="hidden" name="id" value="<?php echo $id; ?>">
                                    </div>
                                </div>
                                <input type="submit" name="add" class="btn btn-primary" value="Add Record">
                            </form>
                           
						</div>
						<!-- footer -->
					</div>
					<!-- end dashboard inner -->
				</div>
			</div>
		</div>
		<!-- jQuery -->
		<script src="../js/jquery.min.js"></script>
		<script src="../js/popper.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<!-- wow animation -->
		<script src="../js/animate.js"></script>
		<!-- select country -->
		<script src="../js/bootstrap-select.js"></script>
		<!-- nice scrollbar -->
		<script src="../js/perfect-scrollbar.min.js"></script>
		<script>
			var ps = new PerfectScrollbar("#sidebar");
		</script>
		<!-- custom js -->
		<script src="../js/custom.js"></script>
	</body>
</html>
